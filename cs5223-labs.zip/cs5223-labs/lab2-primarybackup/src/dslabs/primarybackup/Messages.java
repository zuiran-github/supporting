package dslabs.primarybackup;

import dslabs.atmostonce.AMOApplication;
import dslabs.atmostonce.AMOCommand;
import dslabs.atmostonce.AMOResult;
import dslabs.framework.Message;
import java.util.ArrayList;
import java.util.Set;
import lombok.Data;

/* -------------------------------------------------------------------------
    ViewServer Messages
   -----------------------------------------------------------------------*/
@Data
class Ping implements Message {
    private final int viewNum;
}

@Data
class GetView implements Message {
}

@Data
class ViewReply implements Message {
    private final View view;
}

/* -------------------------------------------------------------------------
    Primary-Backup Messages
   -----------------------------------------------------------------------*/
@Data
class Request implements Message {
    // Your code here...
    private final AMOCommand amoCommand;
}

@Data
class Reply implements Message {
    // Your code here...
    private final AMOResult amoResult;
}

// Your code here...
@Data
class InitializationRequest implements Message {
    private final ArrayList<Request> arrayList;
    private final Set<Request> set;
    private final AMOApplication application;
    private final int sequenceNum;
}


@Data
class BackupReply implements Message {
    private final int sequenceNum;
    private final boolean isOk;
}

@Data
class ForwardRequest implements Message {
    private final AMOCommand command;
    private final ArrayList<Request> arrayList;
    private final Set<Request> set;
    private final int sequenceNum;
    private final int viewNum;
}

@Data
class ForwardReply implements Message {
    private final boolean okReply;
    private final int sequenceNum;
    private final int viewNum;
}

