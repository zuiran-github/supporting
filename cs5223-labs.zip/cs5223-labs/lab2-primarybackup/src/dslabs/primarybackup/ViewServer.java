package dslabs.primarybackup;

import dslabs.framework.Address;
import dslabs.framework.Node;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import static dslabs.primarybackup.PingCheckTimer.PING_CHECK_MILLIS;

@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
class ViewServer extends Node {
    static final int STARTUP_VIEWNUM = 0;
    private static final int INITIAL_VIEWNUM = 1;

    // Your code here...
    private View view;
    private HashSet<Address> liveServer = new HashSet<>();
    private Map<Address, Integer> checkTime = new HashMap<>();
    private boolean isAck = false;

    /* -------------------------------------------------------------------------
        Construction and Initialization
       -----------------------------------------------------------------------*/
    public ViewServer(Address address) {
        super(address);
    }

    @Override
    public void init() {
        this.set(new PingCheckTimer(), PING_CHECK_MILLIS);

        // Your code here...
        view = new View(STARTUP_VIEWNUM,null, null);
    }

    /* -------------------------------------------------------------------------
        Message Handlers
       -----------------------------------------------------------------------*/
    private void handlePing(Ping m, Address sender) {
        // Your code here...

        liveServer.add(sender);
        if ( checkTime.containsKey(sender) ) {
            checkTime.put(sender, 100);
        }

        /* primary initialized and Backup initialized*/
        if (m.viewNum() == STARTUP_VIEWNUM) {

            if (view.primary() == null) {
                // primary initialized
                view = new View(INITIAL_VIEWNUM, sender, null);
            } else {
                if (view.backup() == null && isAck) {
                    // backup initialized
                    view = new View(view.viewNum()+1, view.primary(), sender);
                    isAck = false;
//                    this.send(new ViewReply(view), view.primary());
                }
            }
        } else {

            if ( m.viewNum() == view.viewNum() && view.primary().equals(sender) ) {
                // primary is Ack
                isAck = true;

                if ( view.backup()==null ) {
                    Address newBU = setBackUp();
                    if ( newBU!=null ) {
                        view = new View(view.viewNum()+1, view.primary(), newBU);
                        isAck = false;
                    }
                }
                this.send(new ViewReply(view), sender);
                if (view.backup() != null)
                    this.send(new ViewReply(view), view.backup());
                return;
            }

            if ( !view.primary().equals(sender) && isAck) {

                if ( view.backup() == null ) {
                    Address newBU = setBackUp();
                    view = new View(view.viewNum()+1, view.primary(), newBU);
                    isAck = false;
                }
                this.send(new ViewReply(view), sender);
                this.send(new ViewReply(view), view.primary());
                return;
            }

        }
        this.send(new ViewReply(view), sender);
    }

    private void handleGetView(GetView m, Address sender) {
        // Your code here...
        this.send(new ViewReply(view), sender);
    }

    /* -------------------------------------------------------------------------
        Timer Handlers
       -----------------------------------------------------------------------*/
    private void onPingCheckTimer(PingCheckTimer t) {
        // Your code here...
        this.set(t, PING_CHECK_MILLIS);

        Iterator<Address> iterator = liveServer.iterator();

        while (iterator.hasNext()) {
            Address it = iterator.next();
            if (!checkTime.containsKey(it)) {
                //first check
                checkTime.put(it, 0);
            } else {
                if ( checkTime.get(it)==100 ) {
                    // get ping
                    checkTime.remove(it);
                    continue;
                }
                if ( checkTime.get(it)==0 ) {
                    // dead server
                    iterator.remove();

                    if ( it.equals(view.primary()) && view.backup()!=null && isAck) {
                        // primary die with backup
                        view = new View(view.viewNum()+1, view.backup(), null);
                        isAck = false;
                        Address newBU = setBackUp();
                        view = new View(view.viewNum(), view.primary(), newBU);
                    }

                    if ( it.equals(view.backup()) && isAck ) {
                        // backup die
                        Address newBU = setBackUp();
                        isAck = false;
                        view = new View(view.viewNum()+1, view.primary(), newBU);
                    }

                    checkTime.remove(it);
                }
            }

        }


    }

    /* -------------------------------------------------------------------------
        Utils
       -----------------------------------------------------------------------*/
    // Your code here...

    private Address setBackUp(){
        //        Iterator<Address> addressIt = liveServer.iterator();
        //        Address newBU = null;
        //
        //        while(addressIt.hasNext()){
        //            newBU = addressIt.next();
        //            if(!view.primary().equals(newBU)){
        //                break;
        //            }
        //        }
        //
        //        return newBU;

        ArrayList<Address> list = new ArrayList<>(liveServer);
        Address newBU = null;
        int randomIndex;
        if ( list.size()>1 ) {
            while (true) {
                randomIndex = new Random().nextInt(list.size());
                newBU = list.get(randomIndex);
                if ( newBU!=view.primary() ) {
                    break;
                }
            }
        }

        return newBU;
    }

}