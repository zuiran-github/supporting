package dslabs.primarybackup;

import dslabs.atmostonce.AMOCommand;
import dslabs.atmostonce.AMOResult;
import dslabs.framework.Address;
import dslabs.framework.Client;
import dslabs.framework.Command;
import dslabs.framework.Node;
import dslabs.framework.Result;
import java.util.Objects;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.apache.commons.lang3.RandomStringUtils;

import static dslabs.primarybackup.ClientTimer.CLIENT_RETRY_MILLIS;
import static dslabs.primarybackup.ViewTimer.VIEW_MILLIS;

@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
class PBClient extends Node implements Client {
    private final Address viewServer;

    // Your code here...
    private View localView;
    private int sequenceNum = Integer.parseInt(RandomStringUtils.randomNumeric(5));
//    private Command command;
    private Result result;
    private boolean isSent; // if send the command
    private Command unSentCommand;


    /* -------------------------------------------------------------------------
        Construction and Initialization
       -----------------------------------------------------------------------*/
    public PBClient(Address address, Address viewServer) {
        super(address);
        this.viewServer = viewServer;
    }

    @Override
    public synchronized void init() {
        // Your code here...
        isSent = false;
        this.send(new GetView(), viewServer);
        this.set(new ViewTimer(), VIEW_MILLIS);
    }

    /* -------------------------------------------------------------------------
        Client Methods
       -----------------------------------------------------------------------*/
    @Override
    public synchronized void sendCommand(Command command) {
        // Your code here...

        if (localView==null || localView.viewNum()==0) {
            this.isSent = false;
            this.unSentCommand = command;
            return;
        }

        Address serverAddress = localView.primary();

        this.sequenceNum++;
        this.result = null;

        AMOCommand c = new AMOCommand(command, this.sequenceNum, address());

        this.send(new Request(c), serverAddress);
        this.set(new ClientTimer(this.sequenceNum, command), CLIENT_RETRY_MILLIS);

        if (unSentCommand!=null && unSentCommand.equals(command) && !this.isSent) {
            this.isSent = true;
            this.unSentCommand = null;
        }
//        this.command = null;
    }

    @Override
    public synchronized boolean hasResult() {
        // Your code here...
        return result!=null;
    }

    @Override
    public synchronized Result getResult() throws InterruptedException {
        // Your code here...
        while (result == null)
            this.wait();

        return result;
    }


    /* -------------------------------------------------------------------------
        Message Handlers
       -----------------------------------------------------------------------*/
    // handle reply from prim server
    private synchronized void handleReply(Reply m, Address sender) {
        // Your code here...
        if (m.amoResult().sequenceNum() == sequenceNum) {
            this.result = m.amoResult().result();
            this.notify();
        }
    }

    // handle reply from view server.
    private synchronized void handleViewReply(ViewReply m, Address sender) {
        // Your code here...
        if (m.view().viewNum()==0) {
//            this.send(new GetView(), viewServer);
//            this.set(new ViewTimer(), VIEW_MILLIS);
            return;
        }

        if (localView==null) {
            localView = m.view();
            if (this.unSentCommand!=null && !isSent)
                sendCommand(unSentCommand);
        } else {
            if (localView.viewNum()<m.view().viewNum()) {
                localView = m.view();
                if (this.unSentCommand!=null && !isSent)
                    sendCommand(unSentCommand);
            }
        }

    }

    // Your code here...


    /* -------------------------------------------------------------------------
        Timer Handlers
       -----------------------------------------------------------------------*/
    private synchronized void onClientTimer(ClientTimer t) {
        // Your code here...

        if (Objects.equals(this.sequenceNum, t.sequenceNum()) && result==null) {

            this.send(new GetView(), viewServer);

            if (localView.primary()!=null) {
                AMOCommand c = new AMOCommand(t.command(), t.sequenceNum(), address());
                Address serverAddress = localView.primary();
//                System.out.println("onClientTimer " + localView + " " + serverAddress);
                this.send(new Request(c), serverAddress);
                this.set(t, CLIENT_RETRY_MILLIS);
            }


        }

    }

    //initialize the local view
    private synchronized void onViewTimer(ViewTimer t) {
        if (localView==null) {
            this.send(new GetView(), viewServer);
            this.set(t, VIEW_MILLIS);
        }
    }
}
