package dslabs.primarybackup;

import dslabs.atmostonce.AMOApplication;
import dslabs.atmostonce.AMOCommand;
import dslabs.atmostonce.AMOResult;
import dslabs.framework.Address;
import dslabs.framework.Application;
import dslabs.framework.Node;
import dslabs.kvstore.KVStore;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import lombok.EqualsAndHashCode;
import lombok.ToString;

//import static dslabs.primarybackup.ACKTimer.ACK_MILLIS;
import static dslabs.primarybackup.BackupTimer.BACKUP_MILLIS;
import static dslabs.primarybackup.ForwardTimer.FORWARD_MILLIS;
import static dslabs.primarybackup.PingTimer.PING_MILLIS;
import static dslabs.primarybackup.ViewServer.STARTUP_VIEWNUM;

@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
class PBServer extends Node {
    private final Address viewServer;

    // Your code here...
    private AMOApplication<?> app;
    private boolean isPrimary;
    private boolean isBackup;
    private BackupReply backupReply;
    private boolean isBackedup;
    private View localView;
    private ArrayList<Request> unexecutedCommandList;
    private Set<Request> unexecutedCommandSet;
    private boolean isForwarded;
    private ForwardReply forwardReply;
    private boolean isCover;
    private int forwardSequenceNum; // = Integer.parseInt(RandomStringUtils.randomNumeric(5)); forward request
    private int localNum;
    private int lock;
//    private int initSequenceNum;  //init state transfer
    private int localInitNum;
    private View tView;
    private boolean stateTransferLock;



    /* -------------------------------------------------------------------------
        Construction and Initialization
       -----------------------------------------------------------------------*/
    PBServer(Address address, Address viewServer, Application app) {
        super(address);
        this.viewServer = viewServer;

        // Your code here...
        this.app = new AMOApplication<>((KVStore) app);
        this.unexecutedCommandList = new ArrayList<>();
        this.unexecutedCommandSet = new HashSet<>();
    }

    @Override
    public void init() {
        // Your code here...
        localView = null;
        isPrimary = false;
        isBackup = false;
        isCover = false;
        backupReply = null;
        isBackedup = false;
        isForwarded = false;
        forwardReply = null;
        localNum = 0;
        forwardSequenceNum = 1; //Integer.parseInt(RandomStringUtils.randomNumeric(5));
        lock = forwardSequenceNum;
//        initSequenceNum = 1;
        localInitNum = 0;
        tView = null;
        stateTransferLock = false;  // true = transferring

        //send a mess to view server tell it is alive
        this.send(new Ping(STARTUP_VIEWNUM), viewServer);
        //send ping every PING_MILLIS
        this.set(new PingTimer(), PING_MILLIS);
    }

    /* -------------------------------------------------------------------------
        Message Handlers
       -----------------------------------------------------------------------*/

    //prim receives client command
    private void handleRequest(Request m, Address sender) {
        // Your code here...

        if (!isPrimary) {
            return;
        }

        if (stateTransferLock) {
            return;
        }

        //Initialization
        if (localView == null) {
            if (unexecutedCommandSet.add(m)) {
                unexecutedCommandList.add(m);
            }
            return;
        }


        AMOCommand command;
        if (unexecutedCommandSet==null || unexecutedCommandSet.size()==0) {
            //if command set is null, execute the oncoming request
            command = m.amoCommand();
        } else {
            //else get the first request (FIFO)
            if (unexecutedCommandSet.add(m)) {
                unexecutedCommandList.add(m);
            }
            command = unexecutedCommandList.get(0).amoCommand();
        }


        if ( (lock>1 && lock< forwardSequenceNum) || (lock==1 && forwardSequenceNum ==2) ) {
            // lock=1 first forward request to backup
            // lock>1 at least receive one forward reply
            // lock == sequenceNum received forward reply
            return;
        }


        // Primary server get the request
        if (isPrimary) {

            // Having backup
            if (localView.backup()!=null) {

                if (backupReply==null || !isBackedup) {
                    if (command.equals(m.amoCommand())) {
                        if (unexecutedCommandSet.add(m)){
                            unexecutedCommandList.add(m);
                        }
                    }
                    return;
                }


                //pre-condition
                //Primary sends request to the backup
                if (!isForwarded) {
                    this.send(new ForwardRequest(command, unexecutedCommandList, unexecutedCommandSet, forwardSequenceNum, localView.viewNum()), localView.backup());
                    this.set(new ForwardTimer(command, unexecutedCommandList, unexecutedCommandSet, forwardSequenceNum, localView.viewNum()), FORWARD_MILLIS);
                    forwardSequenceNum++;
                }


                // execute Handle backup reply
                // while backup does not reply, primary cannot send message back
                if (forwardReply==null) {
                    // back up server does not reply, return and send it again.
                    if (unexecutedCommandSet.add(m)) {
                        unexecutedCommandList.add(m);
                    }
                    return;

                } else {
                    if (!isForwarded) {
                        if (unexecutedCommandSet.add(m)) {
                            unexecutedCommandList.add(m);
                        }
                        return;
                    }
                }

                // if backed up, send result to client
            }
            AMOResult amoResult = app.execute(command);
//            System.out.println("app " + address() + " " + app);
            this.send(new Reply(amoResult), command.clientAddress());
            if (unexecutedCommandSet!=null && unexecutedCommandSet.size()>0 && command.equals(unexecutedCommandList.get(0).amoCommand())) {
                unexecutedCommandSet.remove(unexecutedCommandList.get(0));
                unexecutedCommandList.remove(0);
            }
            isForwarded = false;
            forwardReply = null;
        }
    }

    private void handleViewReply(ViewReply m, Address sender) {
        // Your code here...

        if ( localView==null || m.view().viewNum() > localView.viewNum() ) {

            if (m.view().primary().equals(address())) {
                // primary
                isPrimary = true;
                isBackup = false;

                int oldViewNum = 0;

                if (localView!=null) {
                    oldViewNum = localView.viewNum();
                }

                if ( oldViewNum==0 || oldViewNum < m.view().viewNum()) {
                    backupReply = null;
                    isBackedup = false;
                    stateTransferLock = true;
                    isForwarded =false;
                    forwardReply = null;
                    tView = m.view();
                    lock = forwardSequenceNum;
                    if (m.view().backup()!=null) {
                        this.send(new InitializationRequest(unexecutedCommandList, unexecutedCommandSet, app, tView.viewNum()), tView.backup());
                        this.set(new BackupTimer(unexecutedCommandList, unexecutedCommandSet, app, tView.viewNum()), BACKUP_MILLIS);
                    } else {
                        // send ack
                        localView = tView;
                        tView = null;
                        stateTransferLock = false;
//                        this.send(new Ping(localView.viewNum()), viewServer);
                    }
                }

                if (unexecutedCommandSet!=null && unexecutedCommandSet.size()>0) {
                    handleRequest(unexecutedCommandList.get(0), unexecutedCommandList.get(0).amoCommand().clientAddress());
                }

            } else {
                isPrimary = false;
                int oldViewNum = 0;
                if (localView!=null)
                    oldViewNum = localView.viewNum();
                localView = m.view();

                //back up
                isBackup = address().equals(localView.backup());
                if(isBackup && oldViewNum<localView.viewNum()) {
                    isCover = true;
                }
            }
        } else if (isPrimary && m.view().viewNum() == localView.viewNum() && !stateTransferLock) {
            if (unexecutedCommandSet!=null && unexecutedCommandSet.size()>0) {
                handleRequest(unexecutedCommandList.get(0), unexecutedCommandList.get(0).amoCommand().clientAddress());
            }
        }
    }


    // Your code here...

    private void handleInitializationRequest(InitializationRequest m, Address sender) {
        if (!isBackup) {
//            System.out.println("handleInit " + address() + " " + sender);
            this.send(new BackupReply(m.sequenceNum(),false), sender);
            return;
        }


        if (isCover) {
            app = m.application();
            unexecutedCommandList = m.arrayList();
            unexecutedCommandSet = m.set();
            isCover = false;
            localNum = 0;
            localInitNum=m.sequenceNum();
            this.send(new BackupReply(m.sequenceNum(), true), sender);
        }
        else {
            this.send(new BackupReply(localInitNum, true), sender);
        }
    }

    //primary server handle back up reply
    private void handleBackupReply(BackupReply m, Address sender) {

        if (backupReply!=null) {
            if (backupReply.equals(m)) {
                return;
            }
        }

        if (localView.backup()==null) {
            backupReply = null;
            isBackedup = false;
        }

//        System.out.println(address() +" "+ localView + " " + tView +" "+ sender + " "+ m);
        if (tView!=null && tView.viewNum()==m.sequenceNum()) {
            backupReply = m;
            isBackedup = m.isOk();

            if (isBackedup) {
                // state transfer is done, send ack
                localView = tView;
                tView = null;
                stateTransferLock = false;
//                this.send(new Ping(localView.viewNum()), viewServer);
                if (unexecutedCommandSet.size()>0) {
                    handleRequest(unexecutedCommandList.get(0), unexecutedCommandList.get(0).amoCommand().clientAddress());
                }
            }
            else {
                backupReply = null;
                isBackedup = false;
//                // 去掉这行19过不了
//                this.send(new Ping(localView.viewNum()), viewServer);
            }
        }
    }

    private void handleForwardRequest(ForwardRequest m, Address sender) {
        if (isBackup) {

            if (localView.viewNum()!=m.viewNum()) {
                this.send(new ForwardReply(false, localNum, m.viewNum()), sender);
                return;
            }

            if (localView.primary() == sender && (localNum == 0 || localNum < m.sequenceNum())) {
                app.execute(m.command());
                unexecutedCommandList = m.arrayList();
                unexecutedCommandSet = m.set();
                if (unexecutedCommandSet.size()>0) {
                    unexecutedCommandSet.remove(unexecutedCommandList.get(0));
                    unexecutedCommandList.remove(0);
                }
                localNum = m.sequenceNum();
            }
            this.send(new ForwardReply(true, localNum, m.viewNum()), sender);

        } else {
            this.send(new ForwardReply(false, localNum, m.viewNum()), sender);
        }
    }

    private void handleForwardReply(ForwardReply m, Address sender) {

        if (forwardReply!=null) {
            if (forwardReply.equals(m)) {
                return;
            }
        }

        if (isPrimary && sender.equals(localView.backup()) && lock==m.sequenceNum() && !stateTransferLock && localView.viewNum()==m.viewNum()) {
            forwardReply = m;
            isForwarded = m.okReply();
            lock++;
            if (!isForwarded) {
//                this.send(new Ping(localView.viewNum()), viewServer);
                return;
            }

            if (unexecutedCommandSet.size()>0) {
                handleRequest(unexecutedCommandList.get(0), unexecutedCommandList.get(0).amoCommand().clientAddress());
            }
        }
    }


    /* -------------------------------------------------------------------------
        Timer Handlers
       -----------------------------------------------------------------------*/
    private void onPingTimer(PingTimer t) {
        // Your code here...
        if (localView==null) {
            this.send(new Ping(STARTUP_VIEWNUM), viewServer);
        } else {
            this.send(new Ping(localView.viewNum()), viewServer);
        }
        this.set(t, PING_MILLIS);
    }

    // Your code here...
    private void onBackupTimer(BackupTimer t) {
        if (isPrimary && backupReply==null && tView!=null && (localView.backup()!=null||tView.backup()!=null) ) {
//            System.out.println("send init " + address() + " " + tView.backup());
            this.send(new InitializationRequest(t.arrayList(), t.set(), (AMOApplication) t.application(), t.sequenceNum()), tView.backup());
            this.set(t, BACKUP_MILLIS);
        }
        if (localView.backup()==null) {
            if (unexecutedCommandSet.size()>0) {
                handleRequest(unexecutedCommandList.get(0), unexecutedCommandList.get(0).amoCommand().clientAddress());
            }
        }
    }

    private void onForwardTimer(ForwardTimer t) {
        if (isPrimary && forwardReply==null && !stateTransferLock &&localView.backup()!=null && t.sequenceNum()== forwardSequenceNum-1) {
            this.send(new ForwardRequest(t.command(), t.arrayList(), t.set(), t.sequenceNum(), t.viewNum()), localView.backup());
            this.set(t, FORWARD_MILLIS);
        }
    }


    /* -------------------------------------------------------------------------
        Utils
       -----------------------------------------------------------------------*/
    // Your code here...
}
