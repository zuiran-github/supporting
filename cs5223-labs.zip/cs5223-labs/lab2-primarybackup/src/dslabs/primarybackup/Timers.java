package dslabs.primarybackup;

import dslabs.atmostonce.AMOCommand;
import dslabs.framework.Application;
import dslabs.framework.Command;
import dslabs.framework.Timer;
import java.util.ArrayList;
import java.util.Set;
import lombok.Data;
import org.checkerframework.checker.units.qual.Time;

@Data
final class PingCheckTimer implements Timer {
    static final int PING_CHECK_MILLIS = 100;
}

@Data
final class PingTimer implements Timer {
    static final int PING_MILLIS = 25;
}

@Data
final class ClientTimer implements Timer {
    static final int CLIENT_RETRY_MILLIS = 100;
    // Your code here...
    private final int sequenceNum;
    private final Command command;
}

// Your code here...
@Data
final  class ViewTimer implements Timer {
    static final int VIEW_MILLIS = 25;
}

@Data
final class BackupTimer implements Timer {
    static final int BACKUP_MILLIS = 25;
    private final ArrayList<Request> arrayList;
    private final Set<Request> set;
    private final Application application;
    private final int sequenceNum;
}

@Data
final class ForwardTimer implements Timer {
    static final int FORWARD_MILLIS = 25;
    private final AMOCommand command;
    private final ArrayList<Request> arrayList;
    private final Set<Request> set;
    private final int sequenceNum;
    private final int viewNum;
}
