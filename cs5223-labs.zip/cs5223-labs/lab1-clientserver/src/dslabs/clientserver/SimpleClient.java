package dslabs.clientserver;

import dslabs.atmostonce.AMOCommand;
import dslabs.atmostonce.AMOResult;
import dslabs.framework.Address;
import dslabs.framework.Client;
import dslabs.framework.Command;
import dslabs.framework.Node;
import dslabs.framework.Result;
import dslabs.kvstore.KVStore.KVStoreResult;
import dslabs.kvstore.KVStore.SingleKeyCommand;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import static dslabs.clientserver.ClientTimer.CLIENT_RETRY_MILLIS;

/**
 * Simple client that sends requests to a single server and returns responses.
 *
 * See the documentation of {@link Client} and {@link Node} for important
 * implementation notes.
 */
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
class SimpleClient extends Node implements Client {
    private final Address serverAddress;

    // Your code here...
    private AMOCommand latestCommand;
    private AMOResult latestResult;
    private int sequenceNum = 0;

    /* -------------------------------------------------------------------------
        Construction and Initialization
       -----------------------------------------------------------------------*/
    public SimpleClient(Address address, Address serverAddress) {
        super(address);
        this.serverAddress = serverAddress;
    }

    @Override
    public synchronized void init() {
        // No initialization necessary
    }

    /* -------------------------------------------------------------------------
        Client Methods
       -----------------------------------------------------------------------*/
    @Override
    public synchronized void sendCommand(Command command) {
        // Your code here...
        if (!(command instanceof SingleKeyCommand)) {
            throw new IllegalArgumentException();
        }

        this.latestCommand = new AMOCommand(command, this.sequenceNum, address());
        this.latestResult = null;

        send(new Request(latestCommand), serverAddress);
        set(new ClientTimer(sequenceNum), CLIENT_RETRY_MILLIS);
    }

    @Override
    public synchronized boolean hasResult() {
        // Your code here...
        return this.latestResult != null ;
    }

    @Override
    public synchronized Result getResult() throws InterruptedException {
        // Your code here...
        while (latestResult == null) {
            wait();
        }
        sequenceNum++;

        return latestResult.result();  // to return a KVStoreResult, meet the test requirement
    }

    /* -------------------------------------------------------------------------
        Message Handlers
       -----------------------------------------------------------------------*/
    private synchronized void handleReply(Reply m, Address sender) {
        // Your code here...
        if (m.amoResult().sequenceNum() == sequenceNum) {
            this.latestResult = m.amoResult();
            notify();
        }
    }

    /* -------------------------------------------------------------------------
        Timer Handlers
       -----------------------------------------------------------------------*/
    private synchronized void onClientTimer(ClientTimer t) {
        // Your code here...
        if (t.sequenceNum() >= sequenceNum  /*&& latestResult == null*/) {
            send(new Request(this.latestCommand), serverAddress);
            set(t, CLIENT_RETRY_MILLIS);
        }
    }
}
