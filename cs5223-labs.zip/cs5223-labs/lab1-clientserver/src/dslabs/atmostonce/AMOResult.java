package dslabs.atmostonce;

import dslabs.framework.Result;
import lombok.Data;
import dslabs.framework.Address;

@Data
public final class AMOResult implements Result {
    // Your code here...
    private final Result result;
    private final int sequenceNum;
//    private final Address address;
}
